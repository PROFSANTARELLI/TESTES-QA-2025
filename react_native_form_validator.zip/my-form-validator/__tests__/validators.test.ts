import { validateEmail, validateName } from '../src/utils/validators';

describe('Validações de formulário', () => {
  test('Validação de nome', () => {
    expect(validateName('')).toBe('Nome é obrigatório.');
    expect(validateName('A')).toBe('Nome muito curto.');
    expect(validateName('Ana')).toBeUndefined();
  });

  test('Validação de email', () => {
    expect(validateEmail('')).toBe('Email é obrigatório.');
    expect(validateEmail('invalido')).toBe('Email inválido.');
    expect(validateEmail('teste@email.com')).toBeUndefined();
  });
});