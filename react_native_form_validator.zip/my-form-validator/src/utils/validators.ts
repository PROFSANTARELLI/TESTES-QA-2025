export function validateName(name: string): string | undefined {
  if (!name.trim()) return 'Nome é obrigatório.';
  if (name.length < 2) return 'Nome muito curto.';
  return undefined;
}

export function validateEmail(email: string): string | undefined {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email.trim()) return 'Email é obrigatório.';
  if (!regex.test(email)) return 'Email inválido.';
  return undefined;
}